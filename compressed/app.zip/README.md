game-boilerplate
================

A boilerplate for a game project
